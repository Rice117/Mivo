// core/activityLog.ts

export type ActivityType =
  | "agent_started"
  | "agent_completed"
  | "approval_required"
  | "error"
  | "system";

export type Activity = {
  id: string;
  projectId: string;
  agentId?: string;
  type: ActivityType;
  message: string;
  createdAt: string;
};

export function createActivity(
  projectId: string,
  type: ActivityType,
  message: string,
  agentId?: string
): Activity {
  return {
    id: crypto.randomUUID(),
    projectId,
    agentId,
    type,
    message,
    createdAt: new Date().toISOString(),
  };
}
