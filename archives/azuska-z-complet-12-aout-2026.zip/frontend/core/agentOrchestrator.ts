// core/agentOrchestrator.ts
// runAgent() appelle vraiment les 4 agents (welcome, analysis, marketing,
// advertising) au lieu de réponses statiques, gère les cas d'échec
// (données insuffisantes, produit manquant, type inconnu), et enregistre
// chaque exécution dans projectMemory + agentMemory.

import { AgentId, SharedContext, AgentResult } from "./agentTypes";
import { AGENT_REGISTRY } from "@/lib/agents";

export interface MemoryEntry {
  timestamp: string;
  agent: AgentId;
  input: Partial<SharedContext>;
  result: AgentResult;
}

// Mémoires en RAM (à remplacer par database/store.ts + Supabase en production)
export const projectMemory: MemoryEntry[] = [];
export const agentMemory: Record<string, MemoryEntry[]> = {};

function recordMemory(entry: MemoryEntry) {
  projectMemory.push(entry);
  agentMemory[entry.agent] = agentMemory[entry.agent] ?? [];
  agentMemory[entry.agent].push(entry);
}

export function createContext(input: Partial<SharedContext>): SharedContext {
  return { messages: [], ...input };
}

export function runAgent(agentId: AgentId, context: SharedContext): AgentResult {
  const entry = AGENT_REGISTRY[agentId];

  if (!entry) {
    return { agent: agentId, status: "echec", raison: "type d'agent inconnu" };
  }

  // Garde-fous avant exécution, pour des messages d'échec clairs
  if (agentId === "analysis" && (!context.values || context.values.length === 0)) {
    const result: AgentResult = { agent: agentId, status: "echec", raison: "données insuffisantes" };
    recordMemory({ timestamp: new Date().toISOString(), agent: agentId, input: context, result });
    return result;
  }

  if (agentId === "advertising" && !context.positioning) {
    const result: AgentResult = {
      agent: agentId,
      status: "echec",
      raison: "produit manquant : exécuter l'agent marketing avant l'agent publicité",
    };
    recordMemory({ timestamp: new Date().toISOString(), agent: agentId, input: context, result });
    return result;
  }

  const result = entry.agent.run(context);

  recordMemory({
    timestamp: new Date().toISOString(),
    agent: agentId,
    input: context,
    result,
  });

  return result;
}

// Lance la chaîne complète Analyse -> Marketing -> Publicité (+ Accueil en tête),
// chaque agent lisant dans context["messages"] / context partagé ce que
// les précédents ont déjà produit.
export function runPipeline(
  input: Partial<SharedContext>,
  pipeline: AgentId[] = ["welcome", "analysis", "marketing", "advertising"]
) {
  const context = createContext(input);
  const results: Partial<Record<AgentId, AgentResult>> = {};

  for (const agentId of pipeline) {
    results[agentId] = runAgent(agentId, context);
  }

  return { results, messages: context.messages, context };
}
