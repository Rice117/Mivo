// core/agentPlanner.ts
// Analyse une requête en langage naturel (Centre de commande) et construit
// dynamiquement la liste des étapes à exécuter, avec un flag requiresApproval
// par étape pour les actions sensibles (publicité, code).

import { AgentId } from "./agentTypes";

export type PlanStep = {
  agent: AgentId;
  reason: string;
  requiresApproval: boolean;
};

export type ExecutionPlan = {
  request: string;
  locale: string;
  steps: PlanStep[];
};

const KEYWORDS: { agent: AgentId; words: string[]; requiresApproval: boolean }[] = [
  { agent: "analysis", words: ["analyse", "vente", "données", "donnee", "tendance"], requiresApproval: false },
  { agent: "marketing", words: ["marketing", "stratégie", "strategie", "positionnement"], requiresApproval: false },
  { agent: "design", words: ["design", "visuel", "image", "publication", "réseaux sociaux", "reseaux sociaux"], requiresApproval: false },
  { agent: "advertising", words: ["publicité", "publicite", "campagne", "annonce"], requiresApproval: true },
  { agent: "developer", words: ["code", "application", "site", "programme", "fonctionnalité", "fonctionnalite"], requiresApproval: true },
];

export function createPlan(request: string, locale = "fr"): ExecutionPlan {
  const normalized = request.toLowerCase();
  const steps: PlanStep[] = [];

  for (const entry of KEYWORDS) {
    if (entry.words.some((w) => normalized.includes(w))) {
      steps.push({
        agent: entry.agent,
        reason: `Mot-clé détecté correspondant à l'agent ${entry.agent}.`,
        requiresApproval: entry.requiresApproval,
      });
    }
  }

  if (steps.length === 0) {
    steps.push({ agent: "welcome", reason: "Aucun mot-clé reconnu, réponse générale.", requiresApproval: false });
  }

  return { request, locale, steps };
}
