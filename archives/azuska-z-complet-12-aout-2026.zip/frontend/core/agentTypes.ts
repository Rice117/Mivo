// core/agentTypes.ts
// Types partagés par tous les agents et par l'orchestrateur.

export type AgentId = "welcome" | "analysis" | "marketing" | "advertising" | "design" | "developer";

export type AgentStatus = "actif" | "en_attente" | "echec";

export interface AgentMessage {
  agent: AgentId;
  content: string;
}

// Contexte partagé en temps réel entre les agents : chaque agent peut lire
// ce que les précédents ont déjà déposé (trend, positioning, channels...)
// et y ajoute ses propres résultats, plutôt que de tourner isolément.
export interface SharedContext {
  userName?: string;
  objective?: string;
  values?: number[];
  product?: string;
  adObjective?: string;

  // déposé par analysisAgent
  trend?: "hausse" | "baisse" | "stable";
  anomalies?: { index: number; value: number }[];

  // déposé par marketingAgent
  positioning?: string;
  channels?: string[];

  // déposé par designAgent
  visualConcepts?: string[];
  colorPalette?: string[];
  postFormats?: string[];

  // utilisé par developerAgent
  codeRequest?: string;
  projectId?: string;

  messages: AgentMessage[];
}

export interface AgentDescriptor {
  id: AgentId;
  nom: string;
  role: string;
  statut: AgentStatus;
}

export interface AgentResult {
  agent: AgentId;
  status: "success" | "echec";
  [key: string]: unknown;
}
