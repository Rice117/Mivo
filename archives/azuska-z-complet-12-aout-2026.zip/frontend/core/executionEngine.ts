// core/executionEngine.ts
// Boucle sur les étapes du plan ; s'arrête si une étape requiert une
// validation explicite (ex: publicité, développeur), sinon continue.

import { Execution } from "./execution";
import { ExecutionPlan } from "./agentPlanner";

export async function executePlan(
  execution: Execution,
  plan: ExecutionPlan
): Promise<Execution> {
  execution.status = "running";

  for (let i = execution.currentStep; i < plan.steps.length; i++) {
    const step = plan.steps[i];

    if (step.requiresApproval) {
      execution.status = "paused";
      execution.currentStep = i;
      return execution; // attend la validation de l'utilisateur avant de continuer
    }

    try {
      execution.results.push({ agent: step.agent, reason: step.reason });
      execution.currentStep = i + 1;
    } catch (err) {
      execution.status = "failed";
      execution.errors.push(String(err));
      return execution;
    }
  }

  execution.status = "completed";
  return execution;
}
