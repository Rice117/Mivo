// core/execution.ts

export type ExecutionStatus = "pending" | "running" | "paused" | "completed" | "failed";

export type Execution = {
  id: string;
  projectId: string;
  request: string;
  status: ExecutionStatus;
  currentStep: number;
  results: unknown[];
  errors: string[];
};
