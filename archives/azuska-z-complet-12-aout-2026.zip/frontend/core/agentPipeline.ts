// core/agentPipeline.ts
// Enchaîne Analyse -> Marketing -> Design -> Publicité et pousse le
// résultat dans context.memories.

import { ProjectContext } from "./projectContext";
import { analysisAgent } from "@/lib/agents/analysisAgent";
import { marketingAgent } from "@/lib/agents/marketingAgent";
import { designAgent } from "@/lib/agents/designAgent";
import { advertisingAgent } from "@/lib/agents/advertisingAgent";

export async function runFullPipeline(
  context: ProjectContext,
  data: number[],
  product?: string,
  objective?: string
) {
  context.values = data;
  if (product) context.product = product;
  if (objective) context.objective = objective;

  const analysis = analysisAgent.run(context);
  context.analyses.push(analysis);

  if (analysis.status !== "success") {
    context.memories.push({ step: "analysis", result: analysis, at: new Date().toISOString() });
    return { analysis };
  }

  const marketing = marketingAgent.run(context);
  const design = designAgent.run(context);
  const advertising = advertisingAgent.run(context);

  context.memories.push(
    { step: "analysis", result: analysis, at: new Date().toISOString() },
    { step: "marketing", result: marketing, at: new Date().toISOString() },
    { step: "design", result: design, at: new Date().toISOString() },
    { step: "advertising", result: advertising, at: new Date().toISOString() }
  );

  return { analysis, marketing, design, advertising };
}
