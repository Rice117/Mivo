// core/projectContext.ts
import { SharedContext } from "./agentTypes";

export type ProjectContext = SharedContext & {
  projectId: string;
  locale: string;
  analyses: unknown[];
  memories: unknown[];
};

export function createProjectContext(
  projectId: string,
  locale = "fr",
  input: Partial<SharedContext> = {}
): ProjectContext {
  return {
    projectId,
    locale,
    analyses: [],
    memories: [],
    messages: [],
    ...input,
  };
}
