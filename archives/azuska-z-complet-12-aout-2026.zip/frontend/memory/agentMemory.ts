// memory/agentMemory.ts
import { AgentId } from "@/core/agentTypes";

export type AgentMemory = {
  agentId: AgentId;
  information: string;
  createdAt: string;
};

export const agentMemories: AgentMemory[] = [];

export function remember(agentId: AgentId, information: string): AgentMemory {
  const memory: AgentMemory = { agentId, information, createdAt: new Date().toISOString() };
  agentMemories.push(memory);
  return memory;
}
