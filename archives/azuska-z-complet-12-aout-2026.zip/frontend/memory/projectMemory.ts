// memory/projectMemory.ts

export type MemoryItem = {
  id: string;
  projectId: string;
  content: string;
  createdAt: string;
};

export const projectMemory: MemoryItem[] = [];

export function addMemory(projectId: string, content: string): MemoryItem {
  const item: MemoryItem = {
    id: crypto.randomUUID(),
    projectId,
    content,
    createdAt: new Date().toISOString(),
  };
  projectMemory.push(item);
  return item;
}

export function getMemory(projectId: string): MemoryItem[] {
  return projectMemory.filter((m) => m.projectId === projectId);
}
