// lib/agents/analysisAgent.ts
import { SharedContext, AgentResult } from "@/core/agentTypes";

function mean(values: number[]): number {
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function computeTrend(values: number[]): "hausse" | "baisse" | "stable" {
  if (values.length < 2) return "stable";
  const mid = Math.floor(values.length / 2);
  const avgFirst = mean(values.slice(0, mid));
  const avgSecond = mean(values.slice(mid));
  if (avgFirst === 0) return "stable";
  const variation = (avgSecond - avgFirst) / avgFirst;
  if (variation > 0.05) return "hausse";
  if (variation < -0.05) return "baisse";
  return "stable";
}

function findAnomalies(values: number[]): { index: number; value: number }[] {
  if (values.length < 3) return [];
  const avg = mean(values);
  const variance = mean(values.map((v) => (v - avg) ** 2));
  const stdev = Math.sqrt(variance) || 1;
  return values
    .map((value, index) => ({ index, value, z: (value - avg) / stdev }))
    .filter((v) => Math.abs(v.z) >= 2)
    .map(({ index, value }) => ({ index, value }));
}

export const analysisAgent = {
  analyze(values: number[]) {
    const trend = computeTrend(values);
    const anomalies = findAnomalies(values);
    const recommendations: string[] = [];

    if (trend === "hausse") recommendations.push("Renforcer le stock, la demande progresse.");
    else if (trend === "baisse") recommendations.push("Surveiller la baisse de demande.");
    else recommendations.push("Maintenir le niveau de stock actuel.");

    if (anomalies.length > 0) {
      recommendations.push(`${anomalies.length} valeur(s) inhabituelle(s) détectée(s).`);
    }

    return { trend, anomalies, recommendations };
  },

  run(context: SharedContext): AgentResult {
    const values = context.values ?? [];
    if (values.length === 0) {
      context.messages.push({ agent: "analysis", content: "Pas assez de données pour analyser." });
      return { agent: "analysis", status: "echec", raison: "données insuffisantes" };
    }

    const { trend, anomalies, recommendations } = this.analyze(values);

    context.trend = trend;
    context.anomalies = anomalies;
    context.messages.push({
      agent: "analysis",
      content: `Tendance ${trend} détectée. ${recommendations.join(" ")}`,
    });

    return {
      agent: "analysis",
      status: "success",
      tendance: trend,
      anomalies,
      recommandations: recommendations,
    };
  },
};
