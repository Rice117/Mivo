// lib/agents/marketingAgent.ts
import { SharedContext, AgentResult } from "@/core/agentTypes";

const CHANNELS_BY_TREND: Record<string, string[]> = {
  hausse: ["publicité payante", "réseaux sociaux", "email"],
  baisse: ["promotions ciblées", "réactivation clients", "SMS"],
  stable: ["contenu organique", "programme de fidélité"],
};

export const marketingAgent = {
  buildStrategy(objective: string, product: string, trend: string) {
    const channels = CHANNELS_BY_TREND[trend] ?? CHANNELS_BY_TREND.stable;

    let positioning: string;
    let priority: string;

    if (trend === "hausse") {
      positioning = `Capitaliser sur la dynamique actuelle de ${product}.`;
      priority = "haute";
    } else if (trend === "baisse") {
      positioning = `Relancer l'intérêt pour ${product} avant que la baisse ne s'accentue.`;
      priority = "urgente";
    } else {
      positioning = `Consolider la présence de ${product} sur son marché.`;
      priority = "normale";
    }

    const targetAudience = trend === "hausse" ? "nouveaux clients et clients existants" : "clients existants";

    return { positioning, channels, priority, targetAudience };
  },

  // Lit la tendance déjà calculée par analysisAgent dans le contexte partagé,
  // au lieu de tourner isolément.
  run(context: SharedContext): AgentResult {
    const objective = context.objective ?? "développer les ventes";
    const product = context.product ?? "produit non précisé";
    const trend = context.trend ?? "stable";

    const { positioning, channels, priority, targetAudience } = this.buildStrategy(
      objective,
      product,
      trend
    );

    context.positioning = positioning;
    context.channels = channels;
    context.messages.push({
      agent: "marketing",
      content: `Stratégie (${priority}) : ${positioning} Canaux retenus : ${channels.join(", ")}.`,
    });

    return {
      agent: "marketing",
      status: "success",
      objectif: objective,
      positionnement: positioning,
      public_cible: targetAudience,
      canaux: channels,
      priorite: priority,
    };
  },
};
