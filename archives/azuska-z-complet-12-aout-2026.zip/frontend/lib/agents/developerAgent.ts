// lib/agents/developerAgent.ts
// Agent Développeur : à partir d'une demande en langage naturel, propose un
// plan de fichiers à créer/modifier. La génération réelle de code par IA
// sera branchée ici plus tard (appel modèle) ; pour l'instant, l'agent
// produit un plan structuré exploitable par testRunner/gitManager.

import { CodeTask, CodeResult, CodeChange } from "./developerTypes";

function guessAction(path: string, existingFiles: string[] = []): CodeChange["action"] {
  return existingFiles.includes(path) ? "update" : "create";
}

export const developerAgent = {
  async generateCode(task: CodeTask): Promise<CodeResult> {
    const existing = task.existingFiles ?? [];

    // Plan minimal : un seul fichier proposé à partir de la description,
    // à affiner une fois le modèle de génération de code branché.
    const targetPath = `generated/${task.projectId}/${task.id}.ts`;

    const changes: CodeChange[] = [
      {
        path: targetPath,
        content: `// Générée à partir de la demande : "${task.description}"\n// TODO: implémentation réelle\n`,
        action: guessAction(targetPath, existing),
      },
    ];

    return {
      changes,
      summary: `Plan proposé pour : ${task.description}`,
      requiresTests: true,
    };
  },
};
