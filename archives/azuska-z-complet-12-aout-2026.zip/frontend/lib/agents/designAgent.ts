// lib/agents/designAgent.ts
// Agent Design : conçoit la direction visuelle des publications (réseaux
// sociaux, images, campagnes) en s'appuyant sur ce que l'agent marketing
// a déjà déposé dans le contexte partagé (positionnement, canaux), au lieu
// de proposer un visuel générique déconnecté de la stratégie.

import { SharedContext, AgentResult } from "@/core/agentTypes";

// Palettes de couleurs proposées selon la priorité/tonalité de la stratégie
const PALETTES: Record<string, string[]> = {
  urgente: ["#E63946", "#1D3557", "#F1FAEE"], // contrastée, incite à l'action
  haute: ["#2A9D8F", "#264653", "#E9C46A"], // dynamique, confiance
  normale: ["#457B9D", "#A8DADC", "#F1FAEE"], // apaisée, cohérente
};

const FORMATS_BY_CHANNEL: Record<string, string[]> = {
  "réseaux sociaux": ["publication carrée 1080x1080", "story 1080x1920", "carrousel 5 slides"],
  "publicité payante": ["bannière 1200x628", "publication carrée 1080x1080"],
  "promotions ciblées": ["visuel promo avec prix barré", "story compte à rebours"],
  "contenu organique": ["publication carrée 1080x1080", "reel/vidéo courte"],
  email: ["bannière email 600x300"],
  sms: ["visuel miniature pour lien SMS"],
};

export const designAgent = {
  buildConcepts(product: string, positioning: string, channels: string[]) {
    const visualConcepts = [
      `Visuel héro mettant en avant ${product}, aligné sur le message : "${positioning}"`,
      `Déclinaison "avant/après" ou "témoignage client" pour renforcer la confiance`,
      `Série de posts courts (3 à 5) déclinant le même univers graphique pour la cohérence de marque`,
    ];

    const postFormats = Array.from(
      new Set(channels.flatMap((c) => FORMATS_BY_CHANNEL[c] ?? ["publication carrée 1080x1080"]))
    );

    return { visualConcepts, postFormats };
  },

  // Lit le positionnement et les canaux déjà déposés par marketingAgent,
  // comme advertisingAgent le fait, pour rester cohérent avec la stratégie.
  run(context: SharedContext): AgentResult {
    if (!context.positioning) {
      return {
        agent: "design",
        status: "echec",
        raison: "positionnement manquant : exécuter l'agent marketing avant l'agent design",
      };
    }

    const product = context.product ?? "le produit";
    const positioning = context.positioning;
    const channels = context.channels ?? ["contenu organique"];
    const priority = context.channels?.includes("publicité payante") ? "haute" : "normale";

    const palette = PALETTES[priority] ?? PALETTES.normale;
    const { visualConcepts, postFormats } = this.buildConcepts(product, positioning, channels);

    context.visualConcepts = visualConcepts;
    context.colorPalette = palette;
    context.postFormats = postFormats;

    context.messages.push({
      agent: "design",
      content: `Direction visuelle proposée pour ${product} : ${postFormats.join(", ")}.`,
    });

    return {
      agent: "design",
      status: "success",
      concepts_visuels: visualConcepts,
      palette_couleurs: palette,
      formats_publications: postFormats,
    };
  },
};
