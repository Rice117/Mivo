// lib/agents/index.ts
// Dérive la liste des agents directement des vrais agents,
// plutôt qu'une liste dupliquée codée en dur.

import { AgentDescriptor } from "@/core/agentTypes";
import { welcomeAgent } from "./welcomeAgent";
import { analysisAgent } from "./analysisAgent";
import { marketingAgent } from "./marketingAgent";
import { advertisingAgent } from "./advertisingAgent";
import { designAgent } from "./designAgent";

export const AGENT_REGISTRY = {
  welcome: { nom: "Agent Accueil", role: "Accueille l'utilisateur", agent: welcomeAgent },
  analysis: {
    nom: "Agent Analyse",
    role: "Analyse les données importées (tendances, anomalies)",
    agent: analysisAgent,
  },
  marketing: {
    nom: "Agent Marketing",
    role: "Définit la stratégie marketing à partir de l'analyse",
    agent: marketingAgent,
  },
  design: {
    nom: "Agent Design",
    role: "Conçoit les visuels et publications réseaux sociaux à partir de la stratégie marketing",
    agent: designAgent,
  },
  advertising: {
    nom: "Agent Publicité",
    role: "Crée les campagnes publicitaires à partir de la stratégie",
    agent: advertisingAgent,
  },
} as const;

export function listAgents(): AgentDescriptor[] {
  return (Object.keys(AGENT_REGISTRY) as (keyof typeof AGENT_REGISTRY)[]).map((id) => ({
    id,
    nom: AGENT_REGISTRY[id].nom,
    role: AGENT_REGISTRY[id].role,
    statut: "actif",
  }));
}
