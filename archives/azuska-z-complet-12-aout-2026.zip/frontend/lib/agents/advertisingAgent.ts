// lib/agents/advertisingAgent.ts
import { SharedContext, AgentResult } from "@/core/agentTypes";

export const advertisingAgent = {
  // Lit le positionnement produit par marketingAgent (via le contexte partagé).
  run(context: SharedContext): AgentResult {
    const product = context.product ?? "produit non précisé";
    const positioning = context.positioning;
    const channels = context.channels ?? [];
    const adObjective = context.adObjective ?? "générer des ventes";

    if (!positioning) {
      context.messages.push({
        agent: "advertising",
        content: "En attente du positionnement marketing.",
      });
      return {
        agent: "advertising",
        status: "echec",
        raison: "positionnement marketing manquant, exécuter l'agent marketing d'abord",
      };
    }

    const headline = `${product} : ${positioning.replace(/\.$/, "")}.`;
    const share = channels.length > 0 ? Math.round((100 / channels.length) * 10) / 10 : 0;
    const budgetSplit = Object.fromEntries(channels.map((c) => [c, share]));

    context.messages.push({
      agent: "advertising",
      content: `Campagne créée : « ${headline} » diffusée sur ${
        channels.join(", ") || "aucun canal défini"
      }.`,
    });

    return {
      agent: "advertising",
      status: "success",
      objectif_publicitaire: adObjective,
      accroche: headline,
      repartition_budget_pourcent: budgetSplit,
      canaux: channels,
    };
  },
};
