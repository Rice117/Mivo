// lib/dataImporter.ts

export type ImportedData = {
  fileName: string;
  values: number[];
  raw: unknown;
};

function parseCSV(text: string): number[] {
  return text
    .split(/\r?\n/)
    .flatMap((line) => line.split(","))
    .map((cell) => Number(cell.trim()))
    .filter((n) => !Number.isNaN(n));
}

function parseJSONValues(json: unknown): number[] {
  if (Array.isArray(json)) {
    return json.filter((v): v is number => typeof v === "number");
  }
  if (json && typeof json === "object") {
    return Object.values(json as Record<string, unknown>).filter(
      (v): v is number => typeof v === "number"
    );
  }
  return [];
}

export async function importData(file: File): Promise<ImportedData> {
  const text = await file.text();

  if (file.name.endsWith(".json")) {
    const raw = JSON.parse(text);
    return { fileName: file.name, values: parseJSONValues(raw), raw };
  }

  // CSV par défaut
  const values = parseCSV(text);
  return { fileName: file.name, values, raw: text };
}
