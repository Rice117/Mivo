"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { runAgent, createContext } from "@/core/agentOrchestrator";

export default function HomePage() {
  const [userName, setUserName] = useState<string>("");
  const [greeting, setGreeting] = useState<string>("");

  useEffect(() => {
    const context = createContext({ userName: userName || undefined });
    const result = runAgent("welcome", context);
    setGreeting((result.greeting as string) ?? "");
  }, [userName]);

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center gap-8 px-6">
      <div className="text-center space-y-3">
        <p className="text-amber-400 text-sm tracking-widest uppercase">Azuska Z</p>
        <h1 className="text-3xl md:text-4xl font-semibold">{greeting || "Bienvenue"}</h1>
        <p className="text-slate-400 max-w-md mx-auto">
          Vos agents IA analysent vos données, définissent votre stratégie marketing et
          créent vos campagnes publicitaires — ensemble, en temps réel.
        </p>
      </div>

      <input
        type="text"
        placeholder="Votre prénom (optionnel)"
        value={userName}
        onChange={(e) => setUserName(e.target.value)}
        className="w-full max-w-xs rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
      />

      <div className="flex gap-4 flex-wrap justify-center">
        <Link href="/dashboard" className="rounded-md bg-amber-400 text-slate-950 px-5 py-2 font-medium hover:bg-amber-300 transition">
          Aller au tableau de bord
        </Link>
        <Link href="/agents" className="rounded-md border border-slate-700 px-5 py-2 font-medium hover:border-amber-400 transition">
          Voir les agents
        </Link>
      </div>
    </main>
  );
}
