// app/api/analysis/route.ts
import { NextRequest, NextResponse } from "next/server";
import { analysisAgent } from "@/lib/agents/analysisAgent";
import { createProjectContext } from "@/core/projectContext";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const values: number[] = body.values ?? [];
  const projectId: string = body.projectId ?? "default";

  const context = createProjectContext(projectId, body.locale ?? "fr", { values });
  const result = analysisAgent.run(context);

  return NextResponse.json(result);
}
