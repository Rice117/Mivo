"use client";

import Link from "next/link";
import { listAgents } from "@/lib/agents";

const AGENT_LINKS: Record<string, string> = {
  welcome: "/",
  analysis: "/analytics",
  marketing: "/marketing",
  design: "/design",
  advertising: "/advertising",
};

export default function AgentsPage() {
  const agents = listAgents();

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Les agents</h1>
      <p className="text-slate-400 mb-8">Chaque agent est spécialisé et travaille avec les autres.</p>

      <div className="space-y-4 max-w-2xl">
        {agents.map((agent) => (
          <div
            key={agent.id}
            className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900 p-5"
          >
            <div>
              <h2 className="font-medium">{agent.nom}</h2>
              <p className="text-sm text-slate-400">{agent.role}</p>
            </div>
            <Link
              href={AGENT_LINKS[agent.id] ?? "/"}
              className="rounded-md border border-slate-700 px-4 py-2 text-sm hover:border-amber-400 transition"
            >
              Ouvrir
            </Link>
          </div>
        ))}
      </div>
    </main>
  );
}
