"use client";

import { useState } from "react";
import { analysisAgent } from "@/lib/agents/analysisAgent";

// Données d'exemple en attendant la connexion aux vraies données importées.
const SAMPLE_VALUES = [120, 135, 128, 142, 150, 149, 161, 158, 172, 180];

export default function AnalyticsPage() {
  const [result, setResult] = useState<ReturnType<typeof analysisAgent.analyze> | null>(null);

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Agent Analyse</h1>
      <p className="text-slate-400 mb-8">
        Tendance, opportunités et recommandations à partir de vos données.
      </p>

      <button
        onClick={() => setResult(analysisAgent.analyze(SAMPLE_VALUES))}
        className="rounded-md bg-amber-400 text-slate-950 px-5 py-2 font-medium hover:bg-amber-300 transition"
      >
        Lancer une analyse
      </button>

      {result && (
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-5">
            <p className="text-xs uppercase text-slate-500 mb-1">Tendance</p>
            <p className="text-xl font-medium capitalize">{result.trend}</p>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-5">
            <p className="text-xs uppercase text-slate-500 mb-1">Opportunités / anomalies</p>
            <p className="text-xl font-medium">{result.anomalies.length}</p>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-900 p-5 sm:col-span-1 sm:row-span-2">
            <p className="text-xs uppercase text-slate-500 mb-2">Recommandations</p>
            <ul className="space-y-2 text-sm text-slate-300 list-disc list-inside">
              {result.recommendations.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </main>
  );
}
