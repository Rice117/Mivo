"use client";

import { useState, useCallback } from "react";
import Papa from "papaparse";
import * as XLSX from "xlsx";

export default function ImportPage() {
  const [fileName, setFileName] = useState<string>("");
  const [preview, setPreview] = useState<Record<string, unknown>[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string>("");

  const handleFile = useCallback(async (file: File) => {
    setError("");
    setFileName(file.name);
    const ext = file.name.split(".").pop()?.toLowerCase();

    try {
      if (ext === "csv") {
        const text = await file.text();
        const result = Papa.parse(text, { header: true });
        setPreview((result.data as Record<string, unknown>[]).slice(0, 10));
      } else if (ext === "xlsx" || ext === "xls") {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: "array" });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(firstSheet) as Record<string, unknown>[];
        setPreview(rows.slice(0, 10));
      } else if (ext === "json") {
        const text = await file.text();
        const parsed = JSON.parse(text);
        setPreview(Array.isArray(parsed) ? parsed.slice(0, 10) : [parsed]);
      } else {
        setError("Format non pris en charge. Utilisez CSV, Excel (.xlsx) ou JSON.");
      }
    } catch {
      setError("Impossible de lire ce fichier. Vérifiez son format.");
    }
  }, []);

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Importer des données</h1>
      <p className="text-slate-400 mb-8">CSV, Excel ou JSON — utilisées ensuite par l'agent Analyse.</p>

      <label
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          const file = e.dataTransfer.files?.[0];
          if (file) handleFile(file);
        }}
        className={`flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-6 py-16 cursor-pointer transition ${
          dragOver ? "border-amber-400 bg-slate-900" : "border-slate-700"
        }`}
      >
        <span className="text-slate-300">Glissez-déposez un fichier ici, ou cliquez pour choisir</span>
        <span className="text-xs text-slate-500">.csv · .xlsx · .json</span>
        <input
          type="file"
          accept=".csv,.xlsx,.xls,.json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
          }}
        />
      </label>

      {fileName && <p className="mt-4 text-sm text-slate-400">Fichier : {fileName}</p>}
      {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

      {preview.length > 0 && (
        <div className="mt-6 overflow-x-auto rounded-lg border border-slate-800">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-900">
              <tr>
                {Object.keys(preview[0]).map((key) => (
                  <th key={key} className="px-4 py-2 text-left text-slate-300">
                    {key}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {preview.map((row, i) => (
                <tr key={i} className="border-t border-slate-800">
                  {Object.values(row).map((val, j) => (
                    <td key={j} className="px-4 py-2 text-slate-400">
                      {String(val)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
