"use client";

import { listAgents } from "@/lib/agents";
import Link from "next/link";

const AGENT_LINKS: Record<string, string> = {
  welcome: "/",
  analysis: "/analytics",
  marketing: "/marketing",
  design: "/design",
  advertising: "/advertising",
};

export default function DashboardPage() {
  const agents = listAgents();

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Tableau de bord</h1>
      <p className="text-slate-400 mb-8">Vue d'ensemble de vos agents IA.</p>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {agents.map((agent) => (
          <Link
            key={agent.id}
            href={AGENT_LINKS[agent.id] ?? "/agents"}
            className="rounded-lg border border-slate-800 bg-slate-900 p-5 hover:border-amber-400 transition"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs uppercase tracking-wide text-amber-400">
                {agent.statut === "actif" ? "Actif" : "En attente"}
              </span>
              <span
                className={`h-2 w-2 rounded-full ${
                  agent.statut === "actif" ? "bg-emerald-400" : "bg-slate-600"
                }`}
              />
            </div>
            <h2 className="font-medium mb-1">{agent.nom}</h2>
            <p className="text-sm text-slate-400">{agent.role}</p>
          </Link>
        ))}
      </div>

      <div className="mt-8 flex gap-4">
        <Link href="/import" className="text-sm text-amber-400 hover:underline">
          Importer des données →
        </Link>
        <Link href="/overview" className="text-sm text-amber-400 hover:underline">
          Vue d'ensemble du projet →
        </Link>
        <Link href="/command" className="text-sm text-amber-400 hover:underline">
          Centre de commande →
        </Link>
      </div>
    </main>
  );
}
