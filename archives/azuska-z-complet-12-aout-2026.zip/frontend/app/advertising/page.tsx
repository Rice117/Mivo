"use client";

import { useState } from "react";
import { runPipeline } from "@/core/agentOrchestrator";

export default function AdvertisingPage() {
  const [product, setProduct] = useState("");
  const [objective, setObjective] = useState("");
  const [adObjective, setAdObjective] = useState("");
  const [campaign, setCampaign] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState("");

  const handleCreate = () => {
    setError("");
    const { results } = runPipeline({
      product,
      objective,
      adObjective,
      values: [120, 135, 128, 142, 150, 149, 161, 158, 172, 180],
    });

    const adResult = results.advertising;
    if (adResult?.status === "echec") {
      setError(String(adResult.raison));
      setCampaign(null);
    } else {
      setCampaign(adResult ?? null);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Agent Publicité</h1>
      <p className="text-slate-400 mb-8">
        Crée une campagne à partir du positionnement défini par l'agent Marketing.
      </p>

      <div className="space-y-3 max-w-md">
        <input
          placeholder="Produit"
          value={product}
          onChange={(e) => setProduct(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <input
          placeholder="Objectif marketing"
          value={objective}
          onChange={(e) => setObjective(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <input
          placeholder="Objectif publicitaire (ex: générer des ventes)"
          value={adObjective}
          onChange={(e) => setAdObjective(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <button
          onClick={handleCreate}
          disabled={!product || !objective}
          className="rounded-md bg-amber-400 text-slate-950 px-5 py-2 font-medium hover:bg-amber-300 transition disabled:opacity-40"
        >
          Créer la campagne
        </button>
      </div>

      {error && <p className="mt-6 text-sm text-red-400">{error}</p>}

      {campaign && (
        <div className="mt-8 rounded-lg border border-slate-800 bg-slate-900 p-5 max-w-md space-y-2">
          <p className="text-lg font-medium">{String(campaign.accroche)}</p>
          <p className="text-sm text-slate-400">
            Objectif : {String(campaign.objectif_publicitaire)}
          </p>
          <div className="flex flex-wrap gap-2 mt-2">
            {(campaign.canaux as string[]).map((c) => (
              <span key={c} className="text-xs bg-slate-800 rounded-full px-3 py-1">
                {c}
              </span>
            ))}
          </div>
        </div>
      )}
    </main>
  );
}
