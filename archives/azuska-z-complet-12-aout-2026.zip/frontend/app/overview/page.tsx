"use client";

import { listAgents } from "@/lib/agents";
import { projectMemory } from "@/core/agentOrchestrator";

export default function OverviewPage() {
  const agents = listAgents();
  const memoryCount = projectMemory.length;

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Vue d'ensemble du projet</h1>
      <p className="text-slate-400 mb-8">
        Utilisateur → Projet → Données importées, Agents IA, Mémoires, Analyses, Stratégies, Campagnes.
      </p>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-5">
          <p className="text-xs uppercase text-slate-500 mb-1">Agents IA</p>
          <p className="text-2xl font-medium">{agents.length}</p>
        </div>
        <div className="rounded-lg border border-slate-800 bg-slate-900 p-5">
          <p className="text-xs uppercase text-slate-500 mb-1">Mémoires enregistrées</p>
          <p className="text-2xl font-medium">{memoryCount}</p>
        </div>
      </div>

      <div className="mt-8">
        <p className="text-sm text-slate-500 mb-3">Structure</p>
        <pre className="text-xs text-slate-400 bg-slate-900 border border-slate-800 rounded-lg p-4 overflow-x-auto">
{`Utilisateur
 └─ Projet
     ├─ Données importées
     ├─ Agents IA (${agents.length})
     ├─ Mémoires (${memoryCount})
     ├─ Analyses
     ├─ Stratégies marketing
     └─ Campagnes publicitaires`}
        </pre>
      </div>
    </main>
  );
}
