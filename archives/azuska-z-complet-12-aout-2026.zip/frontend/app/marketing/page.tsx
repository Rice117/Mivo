"use client";

import { useState } from "react";
import { marketingAgent } from "@/lib/agents/marketingAgent";
import { analysisAgent } from "@/lib/agents/analysisAgent";

const SAMPLE_VALUES = [120, 135, 128, 142, 150, 149, 161, 158, 172, 180];

export default function MarketingPage() {
  const [objective, setObjective] = useState("");
  const [product, setProduct] = useState("");
  const [strategy, setStrategy] = useState<ReturnType<typeof marketingAgent.buildStrategy> | null>(
    null
  );

  const handleDefine = () => {
    if (!objective || !product) return;
    // Interconnexion : la tendance vient réellement de l'agent Analyse.
    const { trend } = analysisAgent.analyze(SAMPLE_VALUES);
    setStrategy(marketingAgent.buildStrategy(objective, product, trend));
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Agent Marketing</h1>
      <p className="text-slate-400 mb-8">Stratégie construite à partir de la tendance détectée.</p>

      <div className="space-y-3 max-w-md">
        <input
          placeholder="Produit (ex: écouteurs sans fil)"
          value={product}
          onChange={(e) => setProduct(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <input
          placeholder="Objectif (ex: augmenter les ventes)"
          value={objective}
          onChange={(e) => setObjective(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <button
          onClick={handleDefine}
          className="rounded-md bg-amber-400 text-slate-950 px-5 py-2 font-medium hover:bg-amber-300 transition disabled:opacity-40"
          disabled={!objective || !product}
        >
          Définir la stratégie
        </button>
      </div>

      {!strategy && (
        <p className="mt-6 text-sm text-slate-500">
          L'agent Marketing n'a pas encore été lancé pour ce produit.
        </p>
      )}

      {strategy && (
        <div className="mt-8 rounded-lg border border-slate-800 bg-slate-900 p-5 max-w-md space-y-3">
          <p>
            <span className="text-slate-500 text-sm">Positionnement : </span>
            {strategy.positioning}
          </p>
          <p>
            <span className="text-slate-500 text-sm">Public cible : </span>
            {strategy.targetAudience}
          </p>
          <p>
            <span className="text-slate-500 text-sm">Priorité : </span>
            <span className="capitalize">{strategy.priority}</span>
          </p>
          <div>
            <span className="text-slate-500 text-sm">Canaux : </span>
            <div className="flex flex-wrap gap-2 mt-1">
              {strategy.channels.map((c) => (
                <span key={c} className="text-xs bg-slate-800 rounded-full px-3 py-1">
                  {c}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
