"use client";

import { useState } from "react";
import { createPlan, ExecutionPlan } from "@/core/agentPlanner";

export default function CommandPage() {
  const [request, setRequest] = useState("");
  const [plan, setPlan] = useState<ExecutionPlan | null>(null);

  const executeCommand = () => {
    if (!request.trim()) return;
    // Route automatiquement vers le(s) bon(s) agent(s) selon les mots-clés
    // détectés, et affiche le plan avant toute exécution réelle.
    setPlan(createPlan(request, "fr"));
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Centre de commande</h1>
      <p className="text-slate-400 mb-8">
        Décris ta demande en langage naturel, la plateforme choisit les agents à mobiliser.
      </p>

      <div className="max-w-xl space-y-3">
        <textarea
          value={request}
          onChange={(e) => setRequest(e.target.value)}
          placeholder="Ex: analyse les ventes du mois et propose une campagne publicitaire"
          rows={4}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <button
          onClick={executeCommand}
          disabled={!request.trim()}
          className="rounded-md bg-amber-400 text-slate-950 px-5 py-2 font-medium hover:bg-amber-300 transition disabled:opacity-40"
        >
          Exécuter
        </button>
      </div>

      {plan && (
        <div className="mt-8 max-w-xl rounded-lg border border-slate-800 bg-slate-900 p-5 space-y-4">
          <h2 className="font-medium">Plan proposé</h2>
          <ul className="space-y-2">
            {plan.steps.map((step, i) => (
              <li key={i} className="flex items-center justify-between text-sm border-b border-slate-800 pb-2">
                <span>
                  <span className="capitalize">{step.agent}</span> — {step.reason}
                </span>
                {step.requiresApproval && (
                  <span className="text-xs bg-amber-400/20 text-amber-300 rounded-full px-2 py-1">
                    validation requise
                  </span>
                )}
              </li>
            ))}
          </ul>
          <div className="flex gap-3">
            <button className="rounded-md bg-amber-400 text-slate-950 px-4 py-2 text-sm font-medium hover:bg-amber-300 transition">
              Accepter le plan
            </button>
            <button className="rounded-md border border-slate-700 px-4 py-2 text-sm hover:border-amber-400 transition">
              Modifier
            </button>
            <button
              onClick={() => setPlan(null)}
              className="rounded-md border border-slate-700 px-4 py-2 text-sm hover:border-red-400 transition"
            >
              Annuler
            </button>
          </div>
        </div>
      )}
    </main>
  );
}
