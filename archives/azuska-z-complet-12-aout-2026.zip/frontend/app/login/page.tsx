"use client";

import { useState } from "react";
import Link from "next/link";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO : brancher sur Supabase Auth (supabase.auth.signInWithPassword)
    console.log("Connexion (pas encore reliée à Supabase)", { email });
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center px-6">
      <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
        <h1 className="text-2xl font-semibold text-center mb-2">Connexion</h1>
        <input
          type="email"
          required
          placeholder="Adresse email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <input
          type="password"
          required
          placeholder="Mot de passe"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <button
          type="submit"
          className="w-full rounded-md bg-amber-400 text-slate-950 px-5 py-2 font-medium hover:bg-amber-300 transition"
        >
          Se connecter
        </button>
        <p className="text-sm text-slate-500 text-center">
          Pas encore de compte ?{" "}
          <Link href="/signup" className="text-amber-400 hover:underline">
            Créer un compte
          </Link>
        </p>
      </form>
    </main>
  );
}
