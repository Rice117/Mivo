"use client";

import { useState } from "react";
import { designAgent } from "@/lib/agents/designAgent";
import { marketingAgent } from "@/lib/agents/marketingAgent";
import { analysisAgent } from "@/lib/agents/analysisAgent";

const SAMPLE_VALUES = [120, 135, 128, 142, 150, 149, 161, 158, 172, 180];

export default function DesignPage() {
  const [product, setProduct] = useState("");
  const [objective, setObjective] = useState("");
  const [result, setResult] = useState<ReturnType<typeof designAgent.buildConcepts> | null>(null);

  const handleGenerate = () => {
    if (!product || !objective) return;
    // Interconnexion : la direction visuelle s'appuie sur la vraie stratégie marketing,
    // qui s'appuie elle-même sur la vraie tendance d'analyse.
    const { trend } = analysisAgent.analyze(SAMPLE_VALUES);
    const strategy = marketingAgent.buildStrategy(objective, product, trend);
    setResult(designAgent.buildConcepts(product, strategy.positioning, strategy.channels));
  };

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 px-6 py-10">
      <h1 className="text-2xl font-semibold mb-1">Agent Design</h1>
      <p className="text-slate-400 mb-8">
        Direction visuelle et publications réseaux sociaux, alignées sur la stratégie marketing.
      </p>

      <div className="space-y-3 max-w-md">
        <input
          placeholder="Produit (ex: écouteurs sans fil)"
          value={product}
          onChange={(e) => setProduct(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <input
          placeholder="Objectif (ex: augmenter les ventes)"
          value={objective}
          onChange={(e) => setObjective(e.target.value)}
          className="w-full rounded-md bg-slate-900 border border-slate-700 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
        />
        <button
          onClick={handleGenerate}
          className="rounded-md bg-amber-400 text-slate-950 px-5 py-2 font-medium hover:bg-amber-300 transition disabled:opacity-40"
          disabled={!product || !objective}
        >
          Générer la direction visuelle
        </button>
      </div>

      {!result && (
        <p className="mt-6 text-sm text-slate-500">
          L'agent Design n'a pas encore été lancé pour ce produit.
        </p>
      )}

      {result && (
        <div className="mt-8 rounded-lg border border-slate-800 bg-slate-900 p-5 max-w-md space-y-3">
          <div>
            <span className="text-slate-500 text-sm">Concepts visuels :</span>
            <ul className="list-disc list-inside mt-1 space-y-1 text-sm">
              {result.visualConcepts.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          </div>
          <div>
            <span className="text-slate-500 text-sm">Formats de publication :</span>
            <div className="flex flex-wrap gap-2 mt-1">
              {result.postFormats.map((f) => (
                <span key={f} className="text-xs bg-slate-800 rounded-full px-3 py-1">
                  {f}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
