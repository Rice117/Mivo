import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Azuska Z",
  description: "Agents IA pour analyse, stratégie marketing et création publicitaire",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
