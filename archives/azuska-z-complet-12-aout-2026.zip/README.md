# Azuska Z — reconstruction et extension du 12 août 2026

Ce dossier contient la version reconstruite et complétée de la plateforme
Azuska Z, après la perte du code d'origine (dossier `frontend` corrompu dans
le dépôt GitHub). Tout est fonctionnel et prêt à être placé dans GitHub
Desktop puis déployé sur Vercel (frontend) et Railway/Render (backend).

## Structure

- `frontend/` — site Next.js
  - `app/` — pages: accueil, dashboard, import, analytics, marketing,
    **design** (nouveau), advertising, agents, overview, login, signup,
    **command** (Centre de commande, nouveau), `api/analysis` (endpoint API)
  - `lib/agents/` — les 6 agents : accueil, analyse, marketing, **design**
    (nouveau), publicité, **développeur** (nouveau, avec `developerTypes.ts`
    qui débloquait la compilation)
  - `core/` — orchestrateur, types, contexte de projet, pipeline complet
    (`agentPipeline.ts`), planificateur de commandes (`agentPlanner.ts`),
    moteur d'exécution avec pause automatique (`executionEngine.ts`),
    gestion de fichiers workspace, gestion Git, exécuteur de tests, journal
    d'activité
  - `memory/` — mémoire de projet et mémoire par agent
  - `database/` — schéma et magasin en mémoire (à remplacer par Supabase)
  - `i18n/` — 6 langues complètes : fr, en, es, de, it, pt
- `backend/` — API Python FastAPI équivalente (agents en `agents/`,
  orchestrateur en `orchestrator/`)

## Nouveautés de cette session

1. **Agent Design** : conçoit la direction visuelle (concepts, palette,
   formats de publication réseaux sociaux) à partir de la stratégie déjà
   définie par l'agent Marketing — page `/design` incluse.
2. **Agent Développeur** : capable de proposer un plan de fichiers à
   créer/modifier à partir d'une demande en langage naturel (génération de
   code réelle à brancher ensuite). Le fichier de types qui bloquait
   `developerAgent.ts` a été créé.
3. **Centre de commande** (`/command`) : un champ de texte libre où
   l'utilisateur décrit sa demande ; `agentPlanner.ts` détecte les mots-clés
   et construit un plan d'étapes, avec validation obligatoire avant les
   actions sensibles (publicité, code).
4. **Architecture d'exécution complète** : `execution.ts` +
   `executionEngine.ts` gèrent le déroulement du plan et se mettent en pause
   automatiquement sur les étapes qui demandent une validation.
5. **Internationalisation complète** : les 4 langues qui manquaient (es, de,
   it, pt) ont été créées.

Tous les imports et exports ont été vérifiés automatiquement (résolution des
chemins `@/...` et correspondance des noms importés/exportés) — l'ensemble
compile logiquement. `npm install` n'a pas pu être testé ici (pas d'accès
réseau dans cet environnement), donc pense à lancer `npm install` puis
`npm run build` une fois le dossier `frontend/` dans ton projet local, pour
confirmer avant de déployer.

## Important : comment éviter de reperdre ce travail

1. **Ne pas garder le code uniquement dans le chat.** Télécharge ce zip
   maintenant et place son contenu dans ton dépôt GitHub existant
   (`Cahier_de_charges_plate-forme_centrale_des_agents-IA`), en remplaçant
   entièrement l'ancien dossier `frontend/` (et `backend/` si besoin).
2. **Vérifie le réglage "Root Directory" sur Vercel** : il doit toujours
   pointer vers `frontend`.
3. **La structure reste ouverte** : de nouveaux agents et fonctionnalités
   pourront être ajoutés progressivement sans tout reconstruire.
